package IndexServlet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.Enumeration;
/*
*
*
    public void service(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException,IOException
    {

        this.log("执行 service  方法");

        super.service(arg0,arg1);


    }
     public  LifeCycleServlet(){

        this.log("执行 LifeCycleServlet 方法");
    }

* */

public class LifeCycleServlet  extends HttpServlet{

    private  static  double startpoint = 0;


    public  void init(ServletConfig conf) throws ServletException
    {

        super.init(conf);

        ServletConfig config =conf;
        //拿到init方法中的ServletConfig对象

        // --获取当前Servlet 在web.xml中配置的名称（用的不多）
        String sName = config.getServletName();
        System.out.println("当前Servlet 在web.xml中配置的名称:"+sName);
               // --获取当前Servlet中配置的初始化参数（只能获取一个）经常用到
               // String value = config.getInitParameter("name2");
              // System.out.println(value);
               // --获取当前Servlet中配置的初始化参数（全部获取）经常用到
        Enumeration enumration = config.getInitParameterNames();
        while(enumration.hasMoreElements()) {
            String name = (String) enumration.nextElement();
            String value = config.getInitParameter(name);
            System.out.println(name + ":" + value);
        }

        startpoint =Double.parseDouble(config.getInitParameter("startpoint"));
        System.out.println("执行 init 方法");
    }







    public void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException,IOException {
        System.out.println("执行 doget 方法");
        arg0.setAttribute("content","服务器说的话");
        RequestDispatcher d = arg0.getRequestDispatcher("/jsps/lifecycle.jsp");

        d.forward(arg0,arg1);
    }



    public void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException,IOException {

        System.out.println("执行 dopost方法");
    }



    public  void  destroy(){

        System.out.println("执行 destroy 方法");
    }
}
