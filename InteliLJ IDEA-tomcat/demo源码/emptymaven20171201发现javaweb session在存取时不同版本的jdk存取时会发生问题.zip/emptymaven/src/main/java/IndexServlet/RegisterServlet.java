package IndexServlet;

import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.apache.commons.beanutils.BeanUtils;


public class RegisterServlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
    {

        //BeanUtils.setProperty(formbean, "userName", "王洪亮");

        FormBean form=new FormBean();
        try
        {
           BeanUtils.populate(form,request.getParameterMap());

           BeanUtils.setProperty(form,"userName","王洪亮");
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        try
        {
            System.out.println(form.getUserName());
        }
        catch(Exception e)
        {

        }
        response.setContentType("text/html;charset=UTF-8");

        String docType = "<!DOCTYPE html>\n";


        PrintWriter out = response.getWriter();

        out.println(docType+"<html>\n"+"<head><title>"+"注册信息"+"</title></head>\n"+"<body bgcolor=\"#f0f0f0\">\n"+"<h1 align=\"center\">" + "注册信息列表" + "</h1>\n"+ "<ul>\n"+
                "<li><b>用户名:</b>:" + form.getUserName() + "\n</li>" + "<li><b>生日:</b>:" + form.getBirthday() + "\n</li>" + "</ul>\n"+"</body></html>");





    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }


}
