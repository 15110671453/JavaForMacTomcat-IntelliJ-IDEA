package IndexServlet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.Enumeration;

public class HelloForm extends HttpServlet {

    private static final  long serialVersionUID = 1L;


    public  void init(ServletConfig conf) throws ServletException {

        super.init(conf);

        System.out.println("执行 init 方法");
    }

    public void  doGet(HttpServletRequest request ,HttpServletResponse response) throws ServletException,IOException{

        /*
        *
        * 写servlet时当在doGet/doPost方法中要获取ServletContext对象时,（比如：
ServletContext context=getServletContext();
out.print(context.getServerInfo());
）时而会出现下面的异常提示，有时可以有时又不行，找了半天问题总不得要领。
java.lang.NullPointerException
javax.servlet.GenericServlet.getServletContext(GenericServlet.java:159)
servletdemo.FirstServlet.process(FirstServlet.java:51)
原来我重写了init(ServletConfig)，但第一行没有调用super.init(config)；就是这导致了错误！
父类的init(ServletConfig)有处理获取ServletContext对象的引用，
在doGet()等方法中才能够通过getServletContext()方法获取到SeverletContext对象！！
        *
        * */

               ServletContext context = this.getServletContext(); // 得到上下文对象

               // 获取单个的Context里面的初始化参数
                String value1 = context.getInitParameter("function");
                System.out.println(value1 );
                System.out.println();

                // 一次性获取Context里所有的初始化参数
                 Enumeration enumeration = context.getInitParameterNames();
                while (enumeration.hasMoreElements()) {
                         String name = (String) enumeration.nextElement();
                        String value = context.getInitParameter(name);
                        System.out.println(name + ";" + value);

                    }
        //为名字和姓氏创建 Cookie
        /*
        * 需要检查  参数 是否 传递 过来 否则 执行报错
        * */

        String nameCon = request.getParameter("name");
        String urlCon = request.getParameter("url");
        boolean canGo=false;

        if (urlCon!=null &&!urlCon.equals("")&&nameCon!=null &&!nameCon.equals(""))
        {
            canGo=true;
        }else
        {

            canGo=false;
        }

        if (canGo)
        {



                Cookie name = new Cookie("name", URLEncoder.encode(request.getParameter("name"),"UTF-8"));


                Cookie url = new Cookie("url",request.getParameter("url"));

                //为两个Cookie 设置过期日期 为 24 小时 后

                name.setMaxAge(60*60*24);

                url.setMaxAge(60*60*24);


                //在响应头 添加两个Cookie


                response.addCookie(name);

                response.addCookie(url);


                //设置响应内容类型


                response.setContentType("text/html;charset=UTF-8");


                PrintWriter out = response.getWriter();

                String title = "设置Cookie实例";


                String docType = "<!DOCTYPE html>\n";

                String urlS=request.getParameter("url");

                String nameS= request.getParameter("name");

                out.println(docType+"<html>\n"+"<head><title>"+title+"</title></head>\n"+"<body bgcolor=\"#f0f0f0\">\n"+"<h1 align=\"center\">" + title + "</h1>\n"+ "<ul>\n"+
                        "<li><b>Servlet站点名:</b>:" + nameS + "\n</li>" + "<li><b>Servlet站点URL:</b>:" + urlS + "\n</li>" + "</ul>\n"+"</body></html>");



        }else
        {

            response.setCharacterEncoding("UTF-8");

            response.getWriter().println("缺少参数.用法:"+request.getRequestURL()+"?name=dyn&url=www.ouryoung.xin");
        }




    }


    protected  void  doPost(HttpServletRequest request,HttpServletResponse response) throws  ServletException,IOException
    {

        doGet(request,response);
    }
}
