package IndexServlet;

public class FormBean
{

    //<input type="text" name="userName"/>
    private String userName;
    //<input type="password" name="userPwd"/>
    private String userPwd;
    //<input type="password" name="confirmPwd"/>
    private String confirmPwd;
    //<input type="text" name="email"/>
    private String email;
    //<input type="text" name="birthday"/>
    private String birthday;

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getUserPwd() {
        return userPwd;
    }
    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }
    public String getConfirmPwd() {
        return confirmPwd;
    }
    public void setConfirmPwd(String confirmPwd) {
        this.confirmPwd = confirmPwd;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getBirthday() {
        return birthday;
    }
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }



}
